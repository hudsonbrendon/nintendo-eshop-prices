# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['eshop_prices']

package_data = \
{'': ['*']}

install_requires = \
['bs4>=0.0.1,<0.0.2',
 'cchardet>=2.1.7,<3.0.0',
 'lxml>=4.9.2,<5.0.0',
 'pytest>=7.2.2,<8.0.0',
 'requests>=2.28.2,<3.0.0']

setup_kwargs = {
    'name': 'eshop-prices',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Hudson Brendon',
    'author_email': 'contato.hudsonbrendon@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
